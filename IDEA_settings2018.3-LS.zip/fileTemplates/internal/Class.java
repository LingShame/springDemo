#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

/**
 * 
 * @Auther: WangHuidong
 * @Date: ${DATE}
 * @Description: 
 */
public class ${NAME} {
}
